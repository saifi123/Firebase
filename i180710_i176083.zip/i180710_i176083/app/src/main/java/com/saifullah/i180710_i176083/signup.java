package com.saifullah.i180710_i176083;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class signup extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        getSupportActionBar().hide();
        Button signup = findViewById(R.id.signup);
        TextView login = findViewById(R.id.su_login);
        login.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                openlogin();
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                homescreen();
            }
        });

    }

    public void  openlogin()
    {
        Intent intent = new Intent(this,login.class);
        startActivity(intent);

    }

    public void homescreen()
    {
        Intent intent = new Intent(this,home.class);
        startActivity(intent);
    }



}